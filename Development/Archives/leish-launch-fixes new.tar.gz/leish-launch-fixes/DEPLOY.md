# Leish — production fixes (July 8)

## Important: which branch is actually live
Your production deployment (`dpl_9R7Pzsu4zjnQQ15mgz5gS7ooRviX`, still `READY`)
is built from commit `890f4150` on branch **`opencode/sunny-mountain`** — not
`main`. This patch was generated against that exact commit, pulled by SHA
since the branch ref itself is gone from the remote. Apply it to whatever
local checkout currently tracks what's deployed — check with:
```bash
cd ~/Project/migrate-leishmy-to-nextjs
git log -1 --format='%H %s'
# should show 890f4150... "feat: add Events nav link and listing page"
```
If your local branch has moved past that commit already (i.e. you've since
merged `opencode/sunny-mountain` into `main` or elsewhere), just apply the
patch to whatever branch currently contains that Navbar.tsx / proxy.ts / db
code — `git apply --check` will tell you if it doesn't match.

## What this fixes (3 issues, all confirmed live in production via Vercel + Sentry)

### 1. Navbar.tsx was one bad request away from crashing every homepage load
`Navbar.tsx` calls `useTranslations("nav")` from `next-intl`, and renders
`<LanguageSwitcher />`. Neither exists properly:
- `next-intl` is **not in package.json or package-lock.json** — it's not an
  installed dependency at all.
- `./LanguageSwitcher` **doesn't exist anywhere in the repo.**
- There's no `NextIntlClientProvider` anywhere, so even if the package were
  installed, `useTranslations` would still throw.

This is confirmed in Sentry (`NEXTJS-SENTRY-LEISH-2`) as a live, recurring,
unhandled error on `GET /`, most recently a few minutes before this was
written. It's a half-merged multi-language feature — someone (looks like an
agent, commit prefix `opencode/`) generated a huge `src/locales/en.json`
translation file and wired `Navbar.tsx` to it, but the dependency install,
provider setup, and `LanguageSwitcher` component never landed.

**Why this is worse than "some users see an error":** it's currently only
surfacing intermittently (Vercel's build/edge cache is absorbing most
requests), but it means your build has two broken imports sitting behind a
stale cache. The moment Vercel invalidates that build cache — a dependency
bump, a `vercel --force`, moving projects, or just enough time passing — the
**entire production build will fail to compile**, not just this one error.
This needed fixing regardless of traffic level.

**Fix applied:** stripped the `next-intl` / `LanguageSwitcher` calls out of
`Navbar.tsx` and replaced them with the literal English strings already
sitting in `src/locales/en.json`'s `"nav"` section — so nothing visually
changes, it just stops depending on infrastructure that was never finished.
`en.json` itself is untouched — if you want to actually finish the
multi-language feature later, all the translation strings are already there
for every part of the app; it just needs `next-intl` properly installed,
a provider in the root layout, and locale routing wired up. That's a real
project on its own, not a launch-week fix.

### 2. Database connection crashes were killing whole function invocations
`src/db/index.ts` uses a raw `pg.Pool` cached in `globalThis` across
serverless invocations. Neon (like most serverless/pooled Postgres) closes
idle connections server-side. Node's `pg` library requires you to listen for
the pool's `'error'` event on idle-client failures — if nobody does, the
error becomes an **uncaught exception that crashes the whole function**,
not just the one query. Confirmed in Sentry (`NEXTJS-SENTRY-LEISH-1`,
`mechanism: auto.node.onuncaughtexception`), also live, still recurring.

**Fix applied:** added a `pool.on('error', ...)` handler that logs the error
and clears the cached pool so the next request builds a fresh one, instead
of the process crashing outright.

**Worth checking separately (not in this patch, needs your Neon dashboard):**
confirm `DATABASE_URL` in Vercel env vars is the **pooled** connection
string (the one with `-pooler` in the hostname, from Neon's connection
details page) — the direct (non-pooled) string is much more prone to exactly
this kind of idle-disconnect under serverless load.

### 3. Cloudflare beacon CSP block (the console error you originally flagged)
Same fix as before — `script-src`/`connect-src` in `src/proxy.ts` now allow
`cloudflareinsights.com` so the browser stops blocking Cloudflare's
auto-injected analytics beacon. Cosmetic, but visible to anyone opening
devtools, investors included.

### 4. Missing favicon (404 on every page load)
No `favicon.ico` or `app/icon.*` existed anywhere in the repo. Added
`src/app/icon.png` (copied from your existing `public/leishlogo.png`) —
Next.js's App Router auto-serves anything named `icon.*` in `src/app/` as
the site favicon, no code or route needed.

## Don't repeat this mistake
Someone already tried to fix issue #3 on a branch called `feat/multi-language`
(commit `4dcf77d`) by adding a **new `src/middleware.ts`** file that
re-exported the `proxy` function from `src/proxy.ts`. That deployment failed
to build entirely:
```
Error: Both middleware file "./src/src/middleware.ts" and proxy file
"./src/src/proxy.ts" are detected. Please use "./src/src/proxy.ts" only.
```
Next.js's proxy/middleware migration only allows one or the other. This
patch only edits the existing `src/proxy.ts` — do not add a separate
`middleware.ts` alongside it.

## Apply
```bash
cd ~/Project/migrate-leishmy-to-nextjs
git apply --check /path/to/production-fixes.patch   # dry run first
git apply /path/to/production-fixes.patch
git diff --stat   # should show Navbar.tsx, db/index.ts, proxy.ts, app/icon.png
```

## Test locally
```bash
npm run build   # confirms it actually compiles now — this is the important one
npm run dev
# visit localhost:3000, click through the navbar, confirm labels look right
# check the browser tab shows the favicon instead of a blank/default icon
```

## Deploy
```bash
git add src/components/Navbar.tsx src/db/index.ts src/proxy.ts src/app/icon.png
git commit -m "fix: remove broken next-intl integration, handle idle pg pool errors, allow Cloudflare beacon in CSP, add favicon"
git push
```

## After deploy — confirm with me
Once it's live, I can re-pull Vercel runtime errors and Sentry issues to
confirm all three clear. Give it 10-15 minutes of traffic first.
