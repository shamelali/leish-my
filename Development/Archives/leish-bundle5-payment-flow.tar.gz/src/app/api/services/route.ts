import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { services } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const artistId = searchParams.get("artistId");
    const studioId = searchParams.get("studioId");

    if (!artistId && !studioId) {
      return NextResponse.json(
        { error: "artistId or studioId required" },
        { status: 400 }
      );
    }

    const rows = artistId
      ? await db
          .select()
          .from(services)
          .where(eq(services.artistId, Number(artistId)))
      : await db
          .select()
          .from(services)
          .where(eq(services.studioId, Number(studioId)));

    return NextResponse.json({
      services: rows.map((s) => ({
        id: String(s.id),
        name: s.name,
        description: s.description || "",
        duration: s.duration || "",
        price: Number(s.price),
        popular: s.popular || false,
      })),
    });
  } catch (error) {
    console.error("Services GET error:", error);
    return NextResponse.json({ services: [] }, { status: 200 });
  }
}
