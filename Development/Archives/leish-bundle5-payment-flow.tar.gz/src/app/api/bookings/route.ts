import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { bookings, users, artists, studios, services } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getSession } from "@/lib/auth/cookies";

export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { artistId, studioId, serviceId, date, time, status } = body;

    if (!date) {
      return NextResponse.json({ error: "date is required" }, { status: 400 });
    }
    if (!artistId && !studioId) {
      return NextResponse.json(
        { error: "artistId or studioId is required" },
        { status: 400 }
      );
    }

    // Server-side price resolution — never trust a client-submitted amount.
    let amount: number | null = null;

    if (serviceId) {
      const [service] = await db
        .select()
        .from(services)
        .where(eq(services.id, Number(serviceId)))
        .limit(1);
      if (!service) {
        return NextResponse.json({ error: "Service not found" }, { status: 404 });
      }
      // A service must belong to the artist/studio being booked.
      if (
        (artistId && service.artistId !== Number(artistId)) ||
        (studioId && service.studioId !== Number(studioId))
      ) {
        return NextResponse.json(
          { error: "Service does not belong to this artist/studio" },
          { status: 400 }
        );
      }
      amount = Number(service.price);
    } else if (artistId) {
      const [artist] = await db
        .select()
        .from(artists)
        .where(eq(artists.id, Number(artistId)))
        .limit(1);
      if (!artist) {
        return NextResponse.json({ error: "Artist not found" }, { status: 404 });
      }
      amount = Number(artist.price);
    } else if (studioId) {
      const [studio] = await db
        .select()
        .from(studios)
        .where(eq(studios.id, Number(studioId)))
        .limit(1);
      if (!studio) {
        return NextResponse.json({ error: "Studio not found" }, { status: 404 });
      }
      amount = Number(studio.price);
    }

    if (amount === null || Number.isNaN(amount) || amount <= 0) {
      return NextResponse.json(
        { error: "Could not resolve a valid price for this booking" },
        { status: 400 }
      );
    }

    const [booking] = await db
      .insert(bookings)
      .values({
        userId: session.id,
        artistId: artistId ? Number(artistId) : null,
        studioId: studioId ? Number(studioId) : null,
        serviceId: serviceId ? Number(serviceId) : null,
        date: new Date(date),
        time: time || null,
        amount: String(amount),
        status: status === "pending" ? "pending" : "pending",
      })
      .returning();

    return NextResponse.json({ success: true, booking });
  } catch (error) {
    console.error("Booking error:", error);
    return NextResponse.json(
      { error: "Failed to create booking" },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (id) {
      const [booking] = await db
        .select()
        .from(bookings)
        .where(eq(bookings.id, Number(id)))
        .limit(1);

      if (!booking) {
        return NextResponse.json({ error: "Booking not found" }, { status: 404 });
      }

      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.id, booking.userId))
        .limit(1);

      let artistName = "";
      if (booking.artistId) {
        const [artist] = await db
          .select()
          .from(artists)
          .where(eq(artists.id, booking.artistId))
          .limit(1);
        artistName = artist?.name || "";
      }

      return NextResponse.json({
        booking: {
          ...booking,
          id: String(booking.id),
          clientName: user?.name || "Anonymous",
          clientEmail: user?.email || "",
          artistName,
        },
      });
    }

    const allBookings = await db.select().from(bookings);
    return NextResponse.json({ bookings: allBookings });
  } catch (error) {
    console.error("Fetch bookings error:", error);
    return NextResponse.json(
      { error: "Failed to fetch bookings" },
      { status: 500 }
    );
  }
}
