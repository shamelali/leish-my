# Bundle 5 — Wire up the real booking → payment flow

Builds on Bundle 4 (price tampering + auth fix — deploy that first if you
haven't). This closes the actual gap: nobody could complete a real paid
booking through the UI before this.

## What was missing

- `BookingForm.tsx` used a hardcoded list of service *names* (strings),
  never fetched real priced services, never checked if the user was
  signed in, and never called the payment endpoint. Submitting just
  showed a static "Booking Confirmed" — no money ever moved.
- No `/api/services` endpoint existed to look up an artist's real
  services and prices.

## What this bundle adds

- `src/app/api/services/route.ts` (new) — `GET /api/services?artistId=`
  returns real services with real prices for that artist.
- `BookingForm.tsx` (rewritten):
  - Uses the existing `useAuth()` / `AuthContext` — if the visitor isn't
    signed in, shows a "sign in to book" prompt instead of a broken form.
  - Loads real services with real prices via `/api/services`. Falls back
    to the artist's standard rate if they haven't added specific services.
  - Creates the booking (price resolved server-side, per Bundle 4).
  - Immediately creates the Billplz bill for that booking and redirects
    the browser to `bill.url` — this step didn't exist before at all.

## Verified

- `npx tsc --noEmit` — clean
- `npx eslint` on all four changed/new files — clean
- `npx next build` — compiles successfully (the build's internal
  duplicate typecheck pass OOM'd in this sandbox due to a low memory
  limit, unrelated to the code — the standalone `tsc --noEmit` pass
  already confirmed the types are correct; re-run `next build` on your
  own machine/CI to confirm, it should pass there)

## NOT covered by this bundle — do before relying on this in production

1. **Test with real Billplz production keys.** This wires the client
   through to whatever `BILLPLZ_API_URL` / `BILLPLZ_API_KEY` /
   `BILLPLZ_COLLECTION_ID` are set in your environment. Confirm those
   are production values in Vercel, not the sandbox defaults in
   `.env.example`, and run one real end-to-end payment yourself.
2. **`booking/success` page** — confirm it reads real payment status
   from `/api/payments?action=status` rather than assuming success on
   redirect (this existed as a known gap in earlier notes on the old
   codebase; worth a 5-minute check here since this is a fresh rebuild).
3. **Studio booking flow** — this bundle only wires the artist booking
   form. If studios have an equivalent booking component, it needs the
   same treatment (create-bill call + redirect currently likely missing
   there too).
4. **`AUTH_SECRET`** in production env (flagged in Bundle 4 — still
   applies).

## Deploy

```bash
cd leishmy
git apply bundle5-payment-flow.patch
# new file — add directly:
mkdir -p src/app/api/services
cp <this-bundle>/src/app/api/services/route.ts src/app/api/services/route.ts

npx tsc --noEmit
npx eslint src/app/api/services/route.ts src/components/BookingForm.tsx
git add -A
git commit -m "feat: wire booking form to real pricing + Billplz payment redirect"
git push
```
